
import { Subject } from './types';

export const SUBJECT_THEMES = {
  [Subject.History]: {
    color: 'amber',
    bg: 'bg-amber-50',
    border: 'border-amber-200',
    text: 'text-amber-900',
    accent: 'bg-amber-600',
    icon: '🏛️',
    description: 'Explore the events, civilizations, and stories that shaped our world.'
  },
  [Subject.Math]: {
    color: 'blue',
    bg: 'bg-blue-50',
    border: 'border-blue-200',
    text: 'text-blue-900',
    accent: 'bg-blue-600',
    icon: '📐',
    description: 'Master logic, patterns, and problem-solving through visual exploration.'
  },
  [Subject.Science]: {
    color: 'emerald',
    bg: 'bg-emerald-50',
    border: 'border-emerald-200',
    text: 'text-emerald-900',
    accent: 'bg-emerald-600',
    icon: '🧪',
    description: 'Investigate the natural world from atoms to galaxies.'
  }
};

export const GRADE_LEVELS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
