
import React from 'react';
import { openApiKeySelector } from '../services/geminiService';

interface ApiKeyPromptProps {
  onSuccess: () => void;
}

const ApiKeyPrompt: React.FC<ApiKeyPromptProps> = ({ onSuccess }) => {
  const handleSelect = async () => {
    try {
      await openApiKeySelector();
      onSuccess(); // Proceed assuming success as per guidelines
    } catch (err) {
      console.error("Key selection failed", err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm">
      <div className="max-w-md w-full bg-white rounded-2xl p-8 shadow-2xl text-center">
        <div className="mb-6 text-5xl">🔑</div>
        <h2 className="text-2xl font-bold text-slate-900 mb-4">API Key Required</h2>
        <p className="text-slate-600 mb-8">
          To access high-quality educational features and image generation (Gemini 3 Pro), you must select a valid API key from your Google Cloud project.
        </p>
        <button
          onClick={handleSelect}
          className="w-full py-4 px-6 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-xl transition-all shadow-lg hover:shadow-indigo-500/30"
        >
          Select My API Key
        </button>
        <p className="mt-4 text-xs text-slate-400">
          Make sure your key is from a project with billing enabled. 
          <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="underline ml-1">Learn more</a>
        </p>
      </div>
    </div>
  );
};

export default ApiKeyPrompt;
