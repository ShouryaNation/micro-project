
import React, { useState } from 'react';
import { generateEducationalImage } from '../services/geminiService';
import { ImageSize, GeneratedImage } from '../types';

interface VisualLabProps {
  suggestedPrompts: string[];
}

const VisualLab: React.FC<VisualLabProps> = ({ suggestedPrompts }) => {
  const [prompt, setPrompt] = useState('');
  const [size, setSize] = useState<ImageSize>('1K');
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState<GeneratedImage[]>([]);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (targetPrompt?: string) => {
    const finalPrompt = targetPrompt || prompt;
    if (!finalPrompt.trim() || loading) return;

    setLoading(true);
    setError(null);
    try {
      const url = await generateEducationalImage(finalPrompt, size);
      const newImg: GeneratedImage = {
        url,
        prompt: finalPrompt,
        size,
        timestamp: Date.now()
      };
      setHistory(prev => [newImg, ...prev]);
      if (!targetPrompt) setPrompt('');
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Failed to generate image. Please check your API key and permissions.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
        <h3 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
          <span>🖼️</span> Visual Lab
        </h3>
        <p className="text-sm text-slate-600 mb-6">
          Bring your lessons to life. Generate high-resolution historical recreations, scientific diagrams, or mathematical visualizations.
        </p>

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Suggested Visions</label>
            <div className="flex flex-wrap gap-2">
              {suggestedPrompts.map((p, i) => (
                <button
                  key={i}
                  onClick={() => handleGenerate(p)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs rounded-lg transition-colors border border-slate-200"
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="relative">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe what you want to visualize..."
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-4 text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all resize-none h-24"
            />
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-semibold text-slate-500">Quality:</span>
              <div className="flex bg-slate-100 rounded-lg p-1">
                {(['1K', '2K', '4K'] as ImageSize[]).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSize(s)}
                    className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${
                      size === s ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => handleGenerate()}
              disabled={loading || (!prompt.trim() && !loading)}
              className="flex-1 sm:flex-none px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-semibold transition-all shadow-lg disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Generating...
                </>
              ) : (
                'Visualize'
              )}
            </button>
          </div>

          {error && (
            <div className="p-4 bg-red-50 border border-red-100 text-red-600 text-xs rounded-xl">
              {error}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {history.map((img) => (
          <div key={img.timestamp} className="group relative bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm">
            <img src={img.url} alt={img.prompt} className="w-full aspect-video object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity p-4 flex flex-col justify-end">
              <p className="text-white text-xs font-medium line-clamp-2">{img.prompt}</p>
              <span className="text-white/60 text-[10px] uppercase mt-1">Resolution: {img.size}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default VisualLab;
