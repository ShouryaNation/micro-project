
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { Subject, GradeLevel, Message, ImageSize } from "../types";

const getOrdinal = (n: number) => {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return n + (s[(v - 20) % 10] || s[v] || s[0]);
};

export const generateLessonIntro = async (subject: Subject, grade: GradeLevel, topic: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const gradeStr = getOrdinal(grade);
  
  const prompt = `Act as a world-class teacher for a ${gradeStr} grade student. 
  Create a lesson introduction about "${topic}" in the subject of ${subject}.
  The language complexity should be strictly appropriate for a ${gradeStr} grader.
  Include a title, a summary (3 short paragraphs for younger kids, longer for older), 3 key concepts, and 3 suggested image generation prompts for visual aid.
  Focus on deep understanding and "why" rather than just "what".`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: prompt,
    config: {
      responseMimeType: 'application/json',
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          summary: { type: Type.STRING },
          keyConcepts: { type: Type.ARRAY, items: { type: Type.STRING } },
          suggestedPrompts: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ['title', 'summary', 'keyConcepts', 'suggestedPrompts']
      }
    }
  });

  return JSON.parse(response.text);
};

export const chatWithTutor = async (
  subject: Subject, 
  grade: GradeLevel, 
  history: Message[], 
  userInput: string
) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const gradeStr = getOrdinal(grade);
  
  const chat = ai.chats.create({
    model: 'gemini-3-pro-preview',
    config: {
      systemInstruction: `You are an expert tutor in ${subject} for ${gradeStr} grade students. 
      Your goal is to foster deep understanding. Don't just give answers; use the Socratic method, 
      ask probing questions, and use analogies that resonate with a ${gradeStr} grader. 
      If the student is in lower grades (1st-3rd), use very simple language, relatable examples, and keep explanations short.
      Be encouraging and patient.`
    }
  });

  const response = await chat.sendMessage({ message: userInput });
  return response.text;
};

export const generateEducationalImage = async (prompt: string, size: ImageSize) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-image-preview',
    contents: {
      parts: [
        { text: `High-quality educational visualization for a student: ${prompt}. Professional, clear, cinematic lighting, ultra-detailed.` }
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
        imageSize: size
      }
    },
  });

  let imageUrl = '';
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      imageUrl = `data:image/png;base64,${part.inlineData.data}`;
      break;
    }
  }

  if (!imageUrl) throw new Error("No image data returned from API");
  return imageUrl;
};

export const checkApiKeySelection = async () => {
  if (typeof window.aistudio?.hasSelectedApiKey === 'function') {
    return await window.aistudio.hasSelectedApiKey();
  }
  return true;
};

export const openApiKeySelector = async () => {
  if (typeof window.aistudio?.openSelectKey === 'function') {
    await window.aistudio.openSelectKey();
  }
};
