
export enum Subject {
  History = 'History',
  Math = 'Math',
  Science = 'Science'
}

export type GradeLevel = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;

export interface Message {
  role: 'user' | 'model';
  text: string;
}

export interface GeneratedImage {
  url: string;
  prompt: string;
  size: string;
  timestamp: number;
}

export type ImageSize = '1K' | '2K' | '4K';

export interface LessonContent {
  title: string;
  summary: string;
  keyConcepts: string[];
  suggestedPrompts: string[];
}
