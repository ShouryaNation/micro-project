
import React, { useState, useEffect } from 'react';
import { Subject, GradeLevel, LessonContent } from './types';
import { SUBJECT_THEMES, GRADE_LEVELS } from './constants';
import { generateLessonIntro, checkApiKeySelection } from './services/geminiService';
import ApiKeyPrompt from './components/ApiKeyPrompt';
import ChatInterface from './components/ChatInterface';
import VisualLab from './components/VisualLab';

const App: React.FC = () => {
  const [step, setStep] = useState<'intro' | 'setup' | 'learning'>('intro');
  const [grade, setGrade] = useState<GradeLevel>(4);
  const [subject, setSubject] = useState<Subject>(Subject.Science);
  const [topic, setTopic] = useState('');
  const [lesson, setLesson] = useState<LessonContent | null>(null);
  const [loading, setLoading] = useState(false);
  const [needsApiKey, setNeedsApiKey] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      const hasKey = await checkApiKeySelection();
      setNeedsApiKey(!hasKey);
    };
    checkKey();
  }, []);

  const startLearning = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    try {
      const content = await generateLessonIntro(subject, grade, topic);
      setLesson(content);
      setStep('learning');
    } catch (error) {
      console.error(error);
      alert("Something went wrong generating the lesson. Try again!");
    } finally {
      setLoading(false);
    }
  };

  if (needsApiKey) {
    return <ApiKeyPrompt onSuccess={() => setNeedsApiKey(false)} />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => setStep('intro')}>
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white text-xl font-bold">EQ</div>
            <h1 className="font-bold text-xl text-slate-900 hidden sm:block">EduQuest AI</h1>
          </div>
          
          {step === 'learning' && (
            <div className="flex items-center gap-4">
              <div className="px-3 py-1 bg-slate-100 rounded-full text-xs font-semibold text-slate-600">
                Grade {grade}
              </div>
              <div className={`px-3 py-1 ${SUBJECT_THEMES[subject].bg} ${SUBJECT_THEMES[subject].text} rounded-full text-xs font-semibold`}>
                {subject}
              </div>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 flex flex-col">
        {step === 'intro' && (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center max-w-4xl mx-auto">
            <span className="text-6xl mb-6">🚀</span>
            <h2 className="text-4xl sm:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
              Master History, Math & Science with <span className="text-indigo-600">AI Deep Understanding</span>.
            </h2>
            <p className="text-lg text-slate-600 mb-10 max-w-2xl leading-relaxed">
              Experience personalized tutoring that focuses on the "why" behind every concept. From 1st Grade to 10th Standard.
            </p>
            <button
              onClick={() => setStep('setup')}
              className="px-8 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-lg shadow-xl hover:shadow-indigo-500/40 transition-all transform hover:-translate-y-1"
            >
              Start My Quest
            </button>
          </div>
        )}

        {step === 'setup' && (
          <div className="flex-1 p-6 flex items-center justify-center bg-slate-50">
            <div className="max-w-3xl w-full bg-white rounded-3xl p-8 shadow-xl border border-slate-200">
              <h3 className="text-2xl font-bold text-slate-900 mb-8">Set Your Quest Parameters</h3>
              
              <div className="space-y-8">
                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-4">Select Your Grade / Standard</label>
                  <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                    {GRADE_LEVELS.map(g => (
                      <button
                        key={g}
                        onClick={() => setGrade(g as GradeLevel)}
                        className={`aspect-square rounded-xl flex items-center justify-center font-bold transition-all border-2 ${
                          grade === g 
                            ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg scale-105' 
                            : 'bg-white border-slate-100 text-slate-500 hover:border-indigo-200'
                        }`}
                      >
                        {g}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-4">Choose a Subject</label>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {(Object.keys(SUBJECT_THEMES) as Subject[]).map(s => (
                      <button
                        key={s}
                        onClick={() => setSubject(s)}
                        className={`p-4 rounded-2xl text-left transition-all border-2 ${
                          subject === s 
                            ? `${SUBJECT_THEMES[s].border} ${SUBJECT_THEMES[s].bg} ring-2 ring-indigo-500 shadow-md` 
                            : 'bg-white border-slate-100 hover:border-slate-300'
                        }`}
                      >
                        <div className="text-2xl mb-2">{SUBJECT_THEMES[s].icon}</div>
                        <div className="font-bold text-slate-900">{s}</div>
                        <div className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider leading-tight">{SUBJECT_THEMES[s].description}</div>
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold text-slate-700 mb-4">What do you want to learn today?</label>
                  <input
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g., Simple Addition, Planets, Ancient Rome"
                    className="w-full px-5 py-4 bg-slate-100 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 transition-all text-slate-800 placeholder-slate-400"
                  />
                </div>

                <button
                  disabled={!topic.trim() || loading}
                  onClick={startLearning}
                  className="w-full py-5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-bold text-xl shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                >
                  {loading ? (
                    <>
                      <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                      Preparing Lesson...
                    </>
                  ) : (
                    'Begin Lesson'
                  )}
                </button>
              </div>
            </div>
          </div>
        )}

        {step === 'learning' && lesson && (
          <div className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-64px)] overflow-hidden">
            {/* Left Content Area */}
            <div className="flex-1 overflow-y-auto p-6 lg:p-10 scroll-smooth bg-white">
              <div className="max-w-3xl mx-auto space-y-12">
                <section>
                  <h2 className="text-4xl font-extrabold text-slate-900 mb-6 leading-tight">{lesson.title}</h2>
                  <div className="prose prose-slate prose-lg max-w-none text-slate-700 leading-relaxed whitespace-pre-wrap">
                    {lesson.summary}
                  </div>
                </section>

                <section className="bg-slate-50 rounded-3xl p-8 border border-slate-200">
                  <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-2">
                    <span className="w-2 h-8 bg-indigo-500 rounded-full"></span>
                    Key Concepts to Master
                  </h3>
                  <div className="grid grid-cols-1 gap-4">
                    {lesson.keyConcepts.map((concept, i) => (
                      <div key={i} className="flex gap-4 p-4 bg-white rounded-xl border border-slate-200 shadow-sm">
                        <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center font-bold text-sm shrink-0">
                          {i + 1}
                        </div>
                        <p className="text-slate-700 font-medium">{concept}</p>
                      </div>
                    ))}
                  </div>
                </section>

                <section>
                  <VisualLab suggestedPrompts={lesson.suggestedPrompts} />
                </section>
                
                <div className="h-20"></div>
              </div>
            </div>

            {/* Right Side Chat Panel */}
            <div className="w-full lg:w-[400px] xl:w-[450px] border-l border-slate-200 bg-slate-50/50 p-4 shrink-0 overflow-hidden">
              <ChatInterface subject={subject} grade={grade} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
